import React from 'react';
import './ShareComponent_Logo.css'

function ShareComponent_Logo() {
    return (
        <div className="Logo_section">

        <span className="Logo_style">Share
 Component</span>

        </div>
    );
}

export default ShareComponent_Logo;
