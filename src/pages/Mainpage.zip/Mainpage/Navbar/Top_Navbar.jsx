import {React,useEffect,useState} from 'react';
import {Routes, Route, Link, useParams} from 'react-router-dom';
import AIIALogo from './AIIA_Logo.png';
import './Top_Navbar.css';

function Top_Navbar() {

    let links = ['Home','Component','Submit'];

    return (
        <div className="Top_section">

            <div className="Nav_section">

                <div
                    className="Logo_img"
                    style={{
                        background: `url(${AIIALogo}) lightgray 50% / cover no-repeat`,
                        backgroundBlendMode: 'screen',
                    }}
                />

                <div className="Links">


                    <div className="Link_section_Home">
                        <Link to="/">
                            <nav className="Link_style">
                                Home
                            </nav>
                        </Link>
                    </div>

                    <div className="Link_section_Component">
                        <Link to="/Component">
                            <nav className="Link_style">
                                Component
                            </nav>
                        </Link>
                    </div>

                    <div className="Link_section_Submit">
                        <Link to="/Submit">
                            <nav className="Link_style">
                                Submit
                            </nav>
                        </Link>
                    </div>




                </div>

            </div>

            <div className="Action_section">

                <div className="Search">
                    <span className="Search_text">
                        Search...
                    </span>
                </div>

                <div className="Sign">
                    <div className="Sign_section">
                        <span className="Sign_style">
                            Sign in
                        </span>
                    </div>

                    <div className="Sign_section">
                        <span className="Sign_style">
                        Sign in
                        </span>
                    </div>

                </div>


            </div>


        </div>
    );
}

export default Top_Navbar;
