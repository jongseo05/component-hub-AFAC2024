import {React,useEffect,useState} from 'react';
import {Routes, Route, Link, useParams} from 'react-router-dom';
import Dashboard from './Dashboard/Dashboard';
import MainLogo from './MainLogo/ShareComponent_Logo';
import Top_Navbar from "./Navbar/Top_Navbar";

function Homepage(){

    return(
        <div className="Homepage">


            <Top_Navbar/>
            <MainLogo/>
            <Dashboard/>


        </div>
    )

}

export default Homepage;